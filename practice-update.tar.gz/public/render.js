import * as THREE from 'three';
import {buildTrack,at,project,CHARACTERS,obstacles,mod,hazards,hazardState,rampZones,gaps,gapAt,curveProfile} from '/shared/tracks.js';
const loader=new THREE.TextureLoader(), textures=new Map();
function texture(url){if(!textures.has(url)){const t=loader.load(url);t.colorSpace=THREE.SRGBColorSpace;textures.set(url,t);}return textures.get(url);}
export class World{
 constructor(container,settings){this.settings=settings;this.renderer=new THREE.WebGLRenderer({antialias:true,alpha:false,powerPreference:'high-performance'});this.renderer.setPixelRatio(Math.min(devicePixelRatio,settings.quality==='low'?1:1.6));this.renderer.outputColorSpace=THREE.SRGBColorSpace;container.appendChild(this.renderer.domElement);this.scene=new THREE.Scene();this.camera=new THREE.PerspectiveCamera(62,1,.1,1800);this.karts=new Map();this.boxes=[];this.lastTrack=null;this.cameraReady=false;this.clock=0;window.addEventListener('resize',()=>this.resize());this.resize();}
 resize(){this.renderer.setSize(innerWidth,innerHeight);this.camera.aspect=innerWidth/innerHeight;this.camera.updateProjectionMatrix();}
 material(color){return new THREE.MeshLambertMaterial({color});}
 mesh(geo,color,x=0,y=0,z=0,parent=this.scene){const m=new THREE.Mesh(geo,this.material(color));m.position.set(x,y,z);parent.add(m);return m;}
 box(x,y,z,w,h,d,c,parent){return this.mesh(new THREE.BoxGeometry(w,h,d),c,x,y,z,parent);}
 clear(){this.scene.traverse(o=>{o.geometry?.dispose();if(o.material){const ms=Array.isArray(o.material)?o.material:[o.material];ms.forEach(m=>m.dispose());}});this.scene.clear();this.shotGroup=null;this.karts.clear();this.boxes=[];this.predictedBreaks=new Map();this.hazardMeshes=[];this.cameraReady=false;}
 load(id){if(this.lastTrack===id)return;this.lastTrack=id;this.clear();const tr=this.tr=buildTrack(id);this.scene.background=new THREE.Color(tr.sky);this.scene.fog=new THREE.Fog(tr.sky,240,950);this.scene.add(new THREE.HemisphereLight(id==='tololo'?0x9eb5ff:0xe8f5ff,0x3b4d55,2));const sun=new THREE.DirectionalLight(0xfff0dd,2.5);sun.position.set(120,200,70);this.scene.add(sun);
 this.box(80,-20,40,2000,2,2000,tr.ground);
 // Continuous road surface and shoulders follow the exact physical centerline.
 const ribbon=(left,right,color,height)=>{const pos=[],idx=[];for(let i=0;i<tr.points.length;i++){const p=at(tr,tr.points[i].s),y=tr.points[i].y+height;pos.push(p.x+p.nx*left,y,p.z+p.nz*left,p.x+p.nx*right,y,p.z+p.nz*right);if(i<tr.points.length-1&&!gapAt(tr,(tr.points[i].s+tr.points[i+1].s)/2)){const k=i*2;idx.push(k,k+2,k+1,k+1,k+2,k+3);}}const g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.Float32BufferAttribute(pos,3));g.setIndex(idx);g.computeVertexNormals();const m=new THREE.Mesh(g,new THREE.MeshLambertMaterial({color,side:THREE.DoubleSide}));this.scene.add(m);};
 ribbon(-14,14,id==='cordillera'?0xe1eafa:0x6b7e87,-.04);ribbon(-11,11,id==='tololo'?0x353550:0x344354,.01);
 const dummy=new THREE.Object3D();const strips=[];for(let s=0;s<tr.length;s+=5){if(gapAt(tr,s,3))continue;const p=at(tr,s);for(const lane of [-11.45,11.45])strips.push({p,lane,s});}
 const curbs=new THREE.InstancedMesh(new THREE.BoxGeometry(.9,.18,4.9),this.material(0xffffff),strips.length);for(let i=0;i<strips.length;i++){const {p,lane,s}=strips[i];dummy.position.set(p.x+p.nx*lane,p.y+.05,p.z+p.nz*lane);dummy.rotation.set(0,p.yaw,0);dummy.updateMatrix();curbs.setMatrixAt(i,dummy.matrix);curbs.setColorAt(i,new THREE.Color(Math.floor(s/5)%2?0xf5f7ff:0xf45a45));}this.scene.add(curbs);
 const dashes=[];for(let s=25;s<tr.length;s+=13)if(!gapAt(tr,s,3))dashes.push(at(tr,s));const dash=new THREE.InstancedMesh(new THREE.BoxGeometry(.16,.03,4),this.material(0xccd6df),dashes.length);dashes.forEach((p,i)=>{dummy.position.set(p.x,p.y+.05,p.z);dummy.rotation.set(0,p.yaw,0);dummy.updateMatrix();dash.setMatrixAt(i,dummy.matrix);});this.scene.add(dash);
 const start=at(tr,2);for(let x=-10;x<=10;x+=2)for(let z=0;z<2;z++){const p=at(tr,2+z*1.3),o=this.box(p.x+p.nx*x,p.y+.08,p.z+p.nz*x,2,.06,1.3,(x/2+z)%2?0xffffff:0x0d172b);o.rotation.y=p.yaw;}
 const arch=new THREE.Group();arch.position.set(start.x,start.y,start.z);arch.rotation.y=start.yaw;this.scene.add(arch);this.box(-12,5,0,.8,10,1,0x1761ea,arch);this.box(12,5,0,.8,10,1,0x1761ea,arch);this.box(0,10,0,25,2,1,0x0b2c71,arch);this.label('SALIDA / META',0,10,0,18,1.5,arch);
 for(const o of obstacles(tr)){this.box(o.x,o.y+1,o.z,2.5,2,2.5,id==='cordillera'?0xd7edff:0xf89f38);}
 if(id==='cordillera'){const g=new THREE.Group();this.scene.add(g);for(let s=tr.length*.37;s<tr.length*.47;s+=3){if(gapAt(tr,s,2))continue;const p=at(tr,s),b=this.box(p.x,p.y+.04,p.z,21,.02,3.1,0x9ad9e9,g);b.rotation.y=p.yaw;}}
 for(const q of rampZones(tr)){const p=at(tr,tr.length*q),g=new THREE.Group();g.position.set(p.x,p.y,p.z);g.rotation.y=p.yaw;this.scene.add(g);const m=this.box(0,.25,0,22,.3,5,0x35c9fa,g);m.rotation.x=.08;this.label('RAMPA ↑',0,3,-6,9,1.5,g);}
 for(const gap of gaps(tr)){
 for(const s of [gap.start,gap.end]){const p=at(tr,s),edge=this.box(p.x,p.y-.3,p.z,28,.6,.6,0xffc845);edge.rotation.y=p.yaw;}
 const p=at(tr,gap.start-18),sign=this.label('SALTA ↑',p.x+p.nx*12,p.y+4,p.z+p.nz*12,7,1.8);sign.rotation.y=p.yaw+Math.PI;
 }
 this.hazardMeshes=hazards(tr).map(h=>{
 const g=new THREE.Group();g.position.set(h.x,h.y,h.z);g.rotation.y=h.yaw;this.scene.add(g);
 const colors={santiago:0xf4a52e,cordillera:0xb7eaff,tololo:0x8c75ce,pacifico:0x1c9f98,atacama:0xb2683f};
 const block=this.box(0,h.height/2,0,h.width,h.height,h.depth,colors[id],g);
 const marking=this.box(0,.06,0,h.width,.08,h.depth+2,0x45e8a3,g);
 if(h.kind==='drop'){
 this.box(-h.width/2,5.5,0,.3,11,.3,0x536a7a,g);this.box(h.width/2,5.5,0,.3,11,.3,0x536a7a,g);this.box(0,11,0,h.width+.5,.5,1,0x536a7a,g);
 for(let x=-h.width/2+1;x<h.width/2;x+=2)this.box(x,0,.01,.6,h.height+.02,h.depth+.03,0x26303b,block);
 this.label('↓ ATENCIÓN',0,5,-11,8,1.4,g);
 }else{marking.material.color.set(0xffd64b);this.label('SALTAR · A',0,3,-13,9,1.6,g);}
 return {h,block,marking};
 });
 let lastBank=-100;
 for(let s=50;s<tr.length;s+=12){if(curveProfile(tr,s).contraperalte>.2&&s-lastBank>110&&!gapAt(tr,s,25)){const p=at(tr,s-18),sign=this.label('CONTRAPERALTE · FRENA',p.x+p.nx*12,p.y+4,p.z+p.nz*12,12,1.4);sign.rotation.y=p.yaw+Math.PI;sign.material.color.set(0xffd15c);lastBank=s;}}
 this.scenery(tr);
 for(let s=55;s<tr.length;s+=95){const p=at(tr,s),ahead=at(tr,s+22),turn=Math.atan2(Math.sin(ahead.yaw-p.yaw),Math.cos(ahead.yaw-p.yaw));const sign=this.label(turn>.08?'›››':turn<-.08?'‹‹‹':'↑',p.x+p.nx*12,p.y+3,p.z+p.nz*12,3,1.4);sign.rotation.y=p.yaw+Math.PI;}

 }
 label(text,x,y,z,w,h,parent=this.scene){const c=document.createElement('canvas');c.width=1024;c.height=160;const cx=c.getContext('2d');cx.fillStyle='#fff';cx.font='italic 900 80px Arial';cx.textAlign='center';cx.textBaseline='middle';cx.fillText(text,512,80);const tex=new THREE.CanvasTexture(c);tex.colorSpace=THREE.SRGBColorSpace;const m=new THREE.Mesh(new THREE.PlaneGeometry(w,h),new THREE.MeshBasicMaterial({map:tex,transparent:true,side:THREE.DoubleSide,depthWrite:false}));m.position.set(x,y,z+.55);parent.add(m);return m;}
 facade(){if(this.facadeTexture)return this.facadeTexture;const c=document.createElement('canvas');c.width=128;c.height=256;const x=c.getContext('2d');x.fillStyle='#dce6ee';x.fillRect(0,0,128,256);for(let r=0;r<12;r++)for(let col=0;col<5;col++){x.fillStyle=(r+col)%4===0?'#7496b4':'#34536e';x.fillRect(8+col*24,7+r*21,13,13);x.fillStyle='#f0f2ee';x.fillRect(8+col*24,19+r*21,13,2);}const t=new THREE.CanvasTexture(c);t.colorSpace=THREE.SRGBColorSpace;this.facadeTexture=t;return t;}
 scenery(tr){let seed=723+tr.id.length;const rand=()=>{seed=(seed*1664525+1013904223)>>>0;return seed/4294967296;};
 for(let s=0;s<tr.length;s+=18){const p=at(tr,s);for(const side of [-1,1]){const lane=side*(22+rand()*35),x=p.x+p.nx*lane,z=p.z+p.nz*lane;if(Math.abs(project(tr,x,z).offset)<26)continue;
 if(tr.id==='santiago'){const h=8+rand()*34,w=8+rand()*9,d=8+rand()*8;const building=this.box(x,h/2-4,z,w,h,d,[0x9eacbc,0xe8d9c5,0x6b8fad,0xced5da][Math.floor(rand()*4)]);building.material.map=this.facade();this.box(x,h-3.5,z,w+1,.7,d+1,0xe4e2db);if(rand()>.45){const h2=2+rand()*4;this.mesh(new THREE.ConeGeometry(4,h2*2,7),0x346c50,x,p.y+h2,z);}}
 else if(tr.id==='atacama'){this.mesh(new THREE.CylinderGeometry(2+rand()*5,7+rand()*7,12+rand()*20,5),[0xb46c48,0xcb9565,0x9e6348][Math.floor(rand()*3)],x,2,z);}
 else if(tr.id==='cordillera'){this.box(x,0,z,.7,6,.7,0x696463);this.mesh(new THREE.ConeGeometry(3,9,7),0x46766b,x,5,z);this.mesh(new THREE.ConeGeometry(2.6,4,7),0xe8f4f9,x,8,z);}
 else if(tr.id==='pacifico'){if(rand()>.6){this.box(x,-1,z,7,2,17,0xdbe6e4);this.box(x,1,z,3,3,6,0xf2a14a);}else this.mesh(new THREE.ConeGeometry(6,12,6),0x5e8b91,x,-1,z);}
 else {this.mesh(new THREE.IcosahedronGeometry(3+rand()*8,0),0x414c75,x,0,z);if(rand()>.6){const post=this.box(p.x+p.nx*15,p.y+3,p.z+p.nz*15,.2,6,.2,0x727dc3);this.mesh(new THREE.SphereGeometry(.5,6,4),0xcc7dff,post.position.x,p.y+6,post.position.z);}}
 }}
 // Distant geography, kept outside the drivable loop.
 for(let i=0;i<15;i++){const a=i/15*Math.PI*2,r=450+rand()*140;const radius=65+rand()*45,height=110+rand()*100;const mountain=this.mesh(new THREE.ConeGeometry(radius,height,7),tr.id==='atacama'?0xc78e66:tr.id==='tololo'?0x29345e:0x7294ac,80+Math.sin(a)*r,height/2-15,40+Math.cos(a)*r);if(tr.id==='cordillera'||tr.id==='santiago')this.mesh(new THREE.ConeGeometry(radius*.28,height*.28,7),0xe6f0f6,mountain.position.x,height-15-height*.14+.3,mountain.position.z);}
 if(tr.id==='santiago'){const x=65,z=60;this.mesh(new THREE.CylinderGeometry(3,5,58,12),0xc3d3db,x,25,z);for(let h=42;h<55;h+=3)this.mesh(new THREE.CylinderGeometry(9,9,1.5,16),0x354974,x,h,z);this.mesh(new THREE.ConeGeometry(3,12,12),0xf26a3c,x,60,z);this.label('e)',x,35,z+5,8,7);}
 if(tr.id==='atacama'||tr.id==='tololo'){this.mesh(new THREE.CylinderGeometry(12,12,10,18),0xe8e6dd,90,5,50);this.mesh(new THREE.SphereGeometry(12,20,12,0,Math.PI*2,0,Math.PI/2),0xbacde0,90,10,50);}
 if(tr.id==='tololo'){const pos=[];for(let i=0;i<500;i++)pos.push((rand()-.5)*1500,150+rand()*400,(rand()-.5)*1500);const g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.Float32BufferAttribute(pos,3));this.scene.add(new THREE.Points(g,new THREE.PointsMaterial({color:0xd4e4ff,size:1.3})));this.mesh(new THREE.SphereGeometry(25,18,12),0xd7e4ff,-180,220,-300);}
 }
 kart(player){const group=new THREE.Group(),id=player.character;const mesh=new THREE.Mesh(new THREE.PlaneGeometry(3.2,3.2),new THREE.MeshBasicMaterial({map:texture(`/assets/karts/${id}.png`),transparent:true,alphaTest:.07,side:THREE.DoubleSide,depthWrite:true}));const wheelUniforms={wheelPhase:{value:0}};
 mesh.material.onBeforeCompile=shader=>{Object.assign(shader.uniforms,wheelUniforms);shader.fragmentShader='uniform float wheelPhase;\n'+shader.fragmentShader;shader.fragmentShader=shader.fragmentShader.replace('#include <map_fragment>',`#include <map_fragment>
 #ifdef USE_MAP
 vec2 wheelUV=vMapUv;
 float tyreZone=step(wheelUV.y,0.34)*step(0.24,abs(wheelUV.x-0.5));
 float darkTyre=1.0-smoothstep(0.19,0.34,max(diffuseColor.r,max(diffuseColor.g,diffuseColor.b)));
 float tread=sin(wheelUV.y*95.0+wheelPhase*4.0)*0.045;
 diffuseColor.rgb+=vec3(tread*tyreZone*darkTyre);
 #endif`);};
 mesh.material.customProgramCacheKey=()=> 'animated-tyres-v1';
 mesh.userData.wheelUniforms=wheelUniforms;
 mesh.position.y=1.45;group.add(mesh);const shadow=new THREE.Mesh(new THREE.CircleGeometry(1.25,16),new THREE.MeshBasicMaterial({color:0x051426,transparent:true,opacity:.3,depthWrite:false}));shadow.rotation.x=-Math.PI/2;shadow.position.y=.08;group.add(shadow);
 const ring=new THREE.Mesh(new THREE.TorusGeometry(1.4,.055,5,24),new THREE.MeshBasicMaterial({color:CHARACTERS.find(c=>c.id===id)?.color||'#fff'}));ring.rotation.x=Math.PI/2;ring.position.y=.12;group.add(ring);const shield=new THREE.Mesh(new THREE.SphereGeometry(2,16,10),new THREE.MeshBasicMaterial({color:0x6bdcff,transparent:true,opacity:.17,wireframe:true}));shield.position.y=1.4;group.add(shield);this.scene.add(group);const hurt=this.label('¡UY!',0,3.8,0,3,1,group),happy=this.label('¡YUJÚ!',0,3.8,0,4,1,group);hurt.material.color.set(0xffc26a);happy.material.color.set(0x72ffd3);const item={group,mesh,shadow,ring,shield,hurt,happy,character:id};this.karts.set(player.id,item);return item;}
 update(room,local,id,dt){this.load(room.track);this.clock+=dt;
 if(this.lastServerTime!==room.time){this.lastServerTime=room.time;this.serverSeenAt=this.clock;}
 const raceClock=room.time+Math.min(.2,this.clock-this.serverSeenAt);
 for(const {h,block,marking} of this.hazardMeshes){const state=hazardState(h,raceClock);block.position.y=h.height/2+state.lift;if(h.kind==='drop')marking.material.color.set(state.warning||state.blocked?0xff4b3e:0x45e8a3);}
 const me=local||room.players.find(p=>p.id===id)?.kart||room.players.find(p=>p.kart)?.kart;if(!me)return;const travelYaw=me.speed>8?Math.atan2(me.vx,me.vz):me.yaw,slipYaw=Math.atan2(Math.sin(travelYaw-me.yaw),Math.cos(travelYaw-me.yaw)),cameraYaw=me.yaw+slipYaw*.6;const forward=new THREE.Vector3(Math.sin(cameraYaw),0,Math.cos(cameraYaw));const back=(this.settings.motion?10:9)+me.speed*.06;const targetPos=new THREE.Vector3(me.x-forward.x*back,me.y+6,me.z-forward.z*back);const look=new THREE.Vector3(me.x+forward.x*10,me.y+1.5,me.z+forward.z*10);
 if(!this.cameraReady||this.lastRecoveries!==me.recoveries){this.lastRecoveries=me.recoveries;this.camera.position.copy(targetPos);this.look=look;this.cameraReady=true;}else{this.camera.position.lerp(targetPos,1-Math.exp(-dt*8));this.look.lerp(look,1-Math.exp(-dt*10));}this.camera.lookAt(this.look);const targetFov=62+(this.settings.motion?Math.min(5,me.speed/9)+(me.boost>0?4:0):0);this.camera.fov+=(targetFov-this.camera.fov)*Math.min(1,dt*4);this.camera.updateProjectionMatrix();
 for(const p of room.players){if(!p.kart)continue;let item=this.karts.get(p.id);if(item&&item.character!==p.character){this.scene.remove(item.group);this.karts.delete(p.id);item=null;}item ||=this.kart(p);const k=p.id===id&&local?local:p.kart;
 item.wheelPhase=((item.wheelPhase||0)+Math.min(dt,.1)*(k.finished||k.falling?0:k.speed)/.5)%(Math.PI*2);
 item.mesh.userData.wheelUniforms.wheelPhase.value=item.wheelPhase;
 const pos=new THREE.Vector3(k.x,k.y+.03,k.z);item.group.position.lerp(pos,p.id===id?1:1-Math.exp(-dt*16));item.shadow.visible=!gapAt(this.tr,k.s)&&!k.falling;item.ring.visible=!k.falling;item.shadow.position.y=.08+at(this.tr,k.s).y-k.y;item.shadow.scale.setScalar(Math.max(.55,1-Math.max(0,k.y-at(this.tr,k.s).y)*.15));item.ring.position.y=.12+at(this.tr,k.s).y-k.y;item.mesh.quaternion.copy(this.camera.quaternion);item.mesh.rotateZ((k.drift||0)*.035*Math.sin(this.clock*9)+(this.settings.motion&&k.emoteTime>0?(k.emote==='hurt'?.16:.09)*Math.sin(this.clock*18):0));item.mesh.scale.y=k.falling&&k.recoveryReason==='aplastamiento'?.35:1;item.hurt.visible=k.emoteTime>0&&k.emote==='hurt';item.happy.visible=k.emoteTime>0&&k.emote==='happy';for(const bubble of [item.hurt,item.happy])bubble.quaternion.copy(this.camera.quaternion);
 const bearing=Math.atan2(this.camera.position.x-k.x,this.camera.position.z-k.z);let diff=mod(bearing-k.yaw+Math.PI,Math.PI*2)-Math.PI;const view=Math.abs(diff)>Math.PI*.75?'rear':Math.abs(diff)<Math.PI*.25?'front':diff>0?'right':'left';item.mesh.material.map=texture(`/assets/karts/${p.character}-${view}.png`);item.shield.visible=k.shield>0||k.club>0;item.ring.material.color.set(p.id===id?0x63e7ff:0xffc061);item.mesh.material.opacity=p.connected?1:.45;
 }
 for(const [key,item]of this.karts)if(!room.players.some(p=>p.id===key&&p.kart)){this.scene.remove(item.group);this.karts.delete(key);}
 while(this.boxes.length<room.boxes.length){const g=new THREE.Group();const cube=this.mesh(new THREE.BoxGeometry(1.6,1.6,1.6),0x40b5ff,0,1.5,0,g);const edges=new THREE.LineSegments(new THREE.EdgesGeometry(cube.geometry),new THREE.LineBasicMaterial({color:0xb4f4ff}));cube.add(edges);for(const x of [-.35,.35]){this.mesh(new THREE.SphereGeometry(.25,8,6),0xffffff,x,1.6,.82,g);this.mesh(new THREE.SphereGeometry(.12,8,6),0x0d2d65,x,1.6,1.02,g);}const crackGeo=new THREE.BufferGeometry().setFromPoints([new THREE.Vector3(-.65,2.3,.84),new THREE.Vector3(-.15,1.8,.84),new THREE.Vector3(.1,1.7,.84),new THREE.Vector3(-.1,1.35,.84),new THREE.Vector3(.5,.75,.84)]);const cracks=new THREE.Line(crackGeo,new THREE.LineBasicMaterial({color:0xffdd64}));g.add(cracks);g.userData.cracks=cracks;g.userData.intact=[...g.children];const shards=new THREE.InstancedMesh(new THREE.TetrahedronGeometry(.4),new THREE.MeshBasicMaterial({color:0x29bbff,transparent:true}),14);g.add(shards);g.userData.shards=shards;const dust=new THREE.InstancedMesh(new THREE.OctahedronGeometry(.09),new THREE.MeshBasicMaterial({color:0xffcf60,transparent:true}),20);g.add(dust);g.userData.dust=dust;this.scene.add(g);this.boxes.push(g);}
 room.boxes.forEach((b,i)=>{const g=this.boxes[i];
 // Only predict the visual contact. The server alone grants a power.
 let predicted=this.predictedBreaks.get(b.id);
 if(predicted!==undefined&&this.clock-predicted>1&&b.cooldown<=0){this.predictedBreaks.delete(b.id);predicted=undefined;}
 if(predicted===undefined&&b.cooldown<=0&&room.phase==='race'&&local&&Math.abs(local.y-b.y)<2.5&&Math.hypot(local.x-b.x,local.z-b.z)<2.8){predicted=this.clock;this.predictedBreaks.set(b.id,predicted);}
 if(b.cooldown>0&&predicted!==undefined&&this.clock-predicted>1)this.predictedBreaks.delete(b.id);
 const consumed=b.cooldown>0||predicted!==undefined;
 const age=predicted!==undefined?this.clock-predicted:b.brokenAt==null?99:Math.max(0,raceClock-b.brokenAt),breaking=consumed&&age<.8;
 g.visible=!consumed||breaking;g.position.set(b.x,b.y+Math.sin(this.clock*2+i)*.2,b.z);g.rotation.y=this.clock*.7;const u=g.userData;u.intact.forEach(m=>m.visible=!consumed);u.cracks.visible=false;u.shards.visible=breaking&&age<.55;u.dust.visible=breaking&&age>=.08;const dummy=new THREE.Object3D();for(const [mesh,start,duration] of [[u.shards,0,.55],[u.dust,.08,.72]]){if(!mesh.visible)continue;const t=Math.max(0,age-start);mesh.material.opacity=Math.max(0,1-t/duration);for(let j=0;j<mesh.count;j++){const a=j*2.399+i,d=1+t*(j%3+4);dummy.position.set(Math.cos(a)*d,1.5+Math.sin(j*4)*d+t*3-t*t*6,Math.sin(a)*d);dummy.rotation.set(t*(j+1),a+t*5,t*3);dummy.scale.setScalar(mesh===u.shards?1-t*.8:1);dummy.updateMatrix();mesh.setMatrixAt(j,dummy.matrix);mesh.setColorAt(j,new THREE.Color(j%3===0?0xffc43d:j%2?0x267cff:0x6eeaff));}mesh.instanceMatrix.needsUpdate=true;if(mesh.instanceColor)mesh.instanceColor.needsUpdate=true;}});
 this.shotGroup??=new THREE.Group();if(!this.shotGroup.parent)this.scene.add(this.shotGroup);while(this.shotGroup.children.length<room.shots.length)this.box(0,0,0,.7,1.2,.3,0xffaa43,this.shotGroup);this.shotGroup.children.forEach((m,i)=>{const s=room.shots[i];m.visible=!!s;if(s)m.position.set(s.x,s.y,s.z);});
 this.renderer.render(this.scene,this.camera);
 }
}
export function trackSVG(id,me=null){const tr=buildTrack(id);const xs=tr.points.map(p=>p.x),zs=tr.points.map(p=>p.z),minX=Math.min(...xs)-30,maxX=Math.max(...xs)+30,minZ=Math.min(...zs)-30,maxZ=Math.max(...zs)+30;const path=tr.points.filter((_,i)=>i%4===0).map((p,i)=>`${i?'L':'M'}${p.x},${-p.z}`).join(' ')+'Z';return `<svg viewBox="${minX} ${-maxZ} ${maxX-minX} ${maxZ-minZ}" role="img" aria-label="Trazado real de ${tr.name}"><path d="${path}" fill="none" stroke="#071326" stroke-width="29"/><path d="${path}" fill="none" stroke="${tr.color}" stroke-width="18" stroke-linejoin="round"/><path d="${path}" fill="none" stroke="#ffffff65" stroke-width="1.8" stroke-dasharray="5 7"/><circle cx="${tr.points[0].x}" cy="${-tr.points[0].z}" r="8" fill="#fff"/>${me?`<circle cx="${me.x}" cy="${-me.z}" r="8" fill="#ffb53b" stroke="#fff" stroke-width="3"/>`:''}</svg>`;}
