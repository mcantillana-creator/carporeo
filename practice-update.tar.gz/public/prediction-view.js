// Presentation only: never feeds corrected coordinates back into physics.
const angle=v=>Math.atan2(Math.sin(v),Math.cos(v));
export const zeroCorrection=()=>({x:0,y:0,z:0,yaw:0});
export function visibleKart(current,previous,alpha,offset){
 if(!current)return null;
 const p=previous||current,a=Math.max(0,Math.min(1,alpha));
 return {...current,x:p.x+(current.x-p.x)*a+offset.x,y:p.y+(current.y-p.y)*a+offset.y,z:p.z+(current.z-p.z)*a+offset.z,yaw:p.yaw+angle(current.yaw-p.yaw)*a+offset.yaw};
}
export function reconcileView(shown,current){
 if(!shown||shown.recoveries!==current.recoveries||Math.hypot(shown.x-current.x,shown.z-current.z)>32)return zeroCorrection();
 return {x:shown.x-current.x,y:shown.y-current.y,z:shown.z-current.z,yaw:angle(shown.yaw-current.yaw)};
}
