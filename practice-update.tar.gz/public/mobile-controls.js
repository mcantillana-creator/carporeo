const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
export function joystickAxes(x,y){
 const dead=v=>Math.abs(v)<.12?0:Math.sign(v)*clamp((Math.abs(v)-.12)/.88,0,1);
 return {steer:dead(x),throttle:Math.max(0,dead(-y)),brake:y>.38};
}
export function bindJoystick(pad,stick,onChange,isMobile){
 let pointer=null;
 const release=()=>{const old=pointer;pointer=null;stick.style.transform='';pad.classList.remove('pressed');onChange({steer:0,throttle:0,brake:false});if(old!==null&&pad.hasPointerCapture(old))pad.releasePointerCapture(old);};
 const move=e=>{if(e.pointerId!==pointer)return;e.preventDefault();const r=pad.getBoundingClientRect(),mobile=isMobile();
 const x=(e.clientX-r.left-r.width/2)/(r.width*.32),y=(e.clientY-r.top-r.height/2)/(r.height*.32);
 const axes=mobile?joystickAxes(x,y):{steer:clamp(x,-1,1),throttle:0,brake:false};
 onChange(axes);stick.style.transform=`translate(${clamp(x,-1,1)*(mobile?r.width*.28:40)}px,${mobile?clamp(y,-1,1)*r.height*.28:0}px)`;
 };
 pad.addEventListener('pointerdown',e=>{if(pointer!==null)return;pointer=e.pointerId;pad.setPointerCapture(pointer);pad.classList.add('pressed');move(e);});
 pad.addEventListener('pointermove',move);
 for(const event of ['pointerup','pointercancel','lostpointercapture'])pad.addEventListener(event,e=>{if(e.pointerId===pointer)release();});
 return {release};
}
