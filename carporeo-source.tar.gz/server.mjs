import http from 'node:http';
import {readFile,stat} from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {randomBytes,timingSafeEqual} from 'node:crypto';
import {WebSocketServer} from 'ws';
import {TRACKS,CHARACTERS} from './shared/tracks.js';
import {sanitizeInput,DT} from './shared/physics.js';
import {startRace,tickRace,ranking} from './shared/race.js';
const ROOT=path.dirname(fileURLToPath(import.meta.url)),PORT=Number(process.env.PORT||4173),HOST=process.env.HOST||'127.0.0.1';
export const rooms=new Map();
const token=()=>randomBytes(24).toString('base64url'),uid=()=>randomBytes(8).toString('hex');
const send=(ws,data)=>{if(ws.readyState===1){if(ws.bufferedAmount>262144){ws.close(1013,'Conexión lenta');return;}ws.send(JSON.stringify(data));}};
const server=http.createServer(async(req,res)=>{try{const url=new URL(req.url,'http://local');if(url.pathname==='/health'){res.writeHead(200,{'Content-Type':'application/json','Cache-Control':'no-store'});return res.end(JSON.stringify({ok:true}));}
 const allowed={'/vendor/three.module.js':'node_modules/three/build/three.module.js','/vendor/three.core.js':'node_modules/three/build/three.core.js'};
 let rel=allowed[url.pathname]||(url.pathname.startsWith('/shared/')?url.pathname.slice(1):'public'+(url.pathname==='/'?'/index.html':decodeURIComponent(url.pathname)));
 const file=path.resolve(ROOT,rel);if(!file.startsWith(ROOT+path.sep)||rel.includes('..')){res.writeHead(403);return res.end();}const ext=path.extname(file),mime={'.html':'text/html; charset=utf-8','.js':'text/javascript','.css':'text/css','.png':'image/png','.webp':'image/webp','.json':'application/json','.svg':'image/svg+xml'}[ext];if(!mime){res.writeHead(404);return res.end();}
 const body=await readFile(file);res.writeHead(200,{'Content-Type':mime,'Cache-Control':['.html','.js','.css'].includes(ext)?'no-store':'public, max-age=300','X-Content-Type-Options':'nosniff','Referrer-Policy':'no-referrer','Permissions-Policy':'camera=(), microphone=(), geolocation=()','Content-Security-Policy':"default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob:; connect-src 'self'; media-src 'self' blob:; object-src 'none'; frame-ancestors 'none'; base-uri 'none'"});res.end(body);
 }catch{res.writeHead(404);res.end('No encontrado');}});
const wss=new WebSocketServer({noServer:true,maxPayload:8192,perMessageDeflate:false});
server.on('upgrade',(req,socket,head)=>{let valid=false;try{const origin=new URL(req.headers.origin||'');valid=origin.host===req.headers.host||(process.env.PUBLIC_ORIGIN&&origin.origin===process.env.PUBLIC_ORIGIN);}catch{}if(req.url!=='/ws'||!valid||wss.clients.size>=400){socket.write('HTTP/1.1 403 Forbidden\r\n\r\n');socket.destroy();return;}wss.handleUpgrade(req,socket,head,ws=>wss.emit('connection',ws,req));});
function view(room){return {code:room.code,phase:room.phase,host:room.host,practice:room.practice,mode:room.mode,tracks:room.tracks,track:room.track,round:room.round,time:room.time,tune:room.tune,ayudasActivas:false,chat:room.phase==='lobby'?(room.chat||[]):[],players:room.players.map(p=>({id:p.id,name:p.name,character:p.character,connected:p.connected,ready:p.ready,spectator:p.spectator,ack:p.ack,kart:p.kart,points:p.points||0,lastPoints:p.lastPoints||0,place:p.place})),order:room.phase==='race'||room.phase==='results'?ranking(room).map(p=>p.id):[],boxes:room.boxes||[],shots:room.shots||[]};}
function broadcast(room){const v={type:'state',room:view(room)};for(const p of room.players)if(p.connected&&p.ws)send(p.ws,v);}
function transfer(room){if(!room.players.some(p=>p.id===room.host&&p.connected))room.host=room.players.find(p=>p.connected)?.id||null;}
function detach(ws,remove=false){const room=rooms.get(ws.room),p=room?.players.find(p=>p.id===ws.pid);if(p&&p.ws===ws){p.connected=false;p.ws=null;p.leftAt=Date.now();p.lastInput={};p.queue=[];if(remove){p.token=null;p.leftAt=0;if(room.phase==='lobby')room.players=room.players.filter(q=>q!==p);}transfer(room);broadcast(room);}ws.pid=null;ws.room=null;}
const cleanName=n=>typeof n==='string'?n.replace(/[<>\u0000-\u001f\u007f]/g,'').trim().slice(0,20)||'Piloto':'Piloto';
function attach(ws,room,p){ws.pid=p.id;ws.room=room.code;p.ws=ws;p.connected=true;p.leftAt=null;room.lastActive=Date.now();transfer(room);send(ws,{type:'joined',id:p.id,token:p.token,code:room.code});broadcast(room);}
wss.on('connection',ws=>{ws.isAlive=true;ws.count=0;ws.window=Date.now();ws.on('pong',()=>ws.isAlive=true);
 ws.on('message',raw=>{try{if(Date.now()-ws.window>1000){ws.window=Date.now();ws.count=0;}if(++ws.count>70){ws.close(1008,'Demasiadas solicitudes');return;}
 const m=JSON.parse(raw);if(!m||typeof m.type!=='string')return;let room=rooms.get(ws.room),p=room?.players.find(p=>p.id===ws.pid);const error=message=>send(ws,{type:'error',message});
 if(m.type==='ping'){send(ws,{type:'pong',sent:m.sent});return;}
 if(m.type==='resume'){const r=rooms.get(String(m.code)),found=r?.players.find(q=>typeof m.token==='string'&&q.token&&q.token.length===m.token.length&&timingSafeEqual(Buffer.from(q.token),Buffer.from(m.token)));if(!found||(!found.connected&&Date.now()-found.leftAt>30000))return error('La sesión venció. Vuelve a entrar a la sala.');if(found.ws&&found.ws!==ws){found.ws.pid=null;found.ws.room=null;found.ws.close();}detach(ws);attach(ws,r,found);return;}
 if(m.type==='create'){if(rooms.size>=Number(process.env.MAX_ROOMS||40))return error('No quedan salas disponibles. Intenta más tarde.');detach(ws,true);const code=randomBytes(7).toString('hex').toUpperCase(),id=uid();room={code,host:id,practice:m.practice===true,mode:'race',phase:'lobby',tracks:['santiago'],track:'santiago',round:0,time:0,players:[],tune:'equilibrado',ayudasActivas:false,chat:[],lastActive:Date.now(),created:Date.now()};rooms.set(code,room);p={id,token:token(),name:cleanName(m.name),character:'entelin',ready:false,queue:[],lastInput:{},seq:0,ack:0};room.players.push(p);attach(ws,room,p);return;}
 if(m.type==='join'){const r=rooms.get(String(m.code).toUpperCase());if(!r||r.practice)return error('La sala no existe o ya cerró.');if(r.players.length>=8)return error('La sala está llena.');detach(ws,true);p={id:uid(),token:token(),name:cleanName(m.name),character:'entelin',ready:false,queue:[],lastInput:{},seq:0,ack:0,spectator:r.phase!=='lobby'};r.players.push(p);attach(ws,r,p);return;}
 if(!p||!room)return error('Primero entra a una sala.');room.lastActive=Date.now();
 if(m.type==='leave'){detach(ws,true);send(ws,{type:'left'});return;}
 if(m.type==='input'){if(room.phase!=='race'||!p.kart||p.spectator)return;if(!Array.isArray(m.frames)||m.frames.length>8)return;for(const f of m.frames){if(!Number.isSafeInteger(f.seq)||f.seq<=p.seq||f.seq>p.seq+120||!f.input)continue;if(p.queue.length>=15)break;p.seq=f.seq;p.queue.push({seq:f.seq,input:sanitizeInput(f.input)});}return;}
 if(m.type==='select'&&room.phase==='lobby'){if(CHARACTERS.some(c=>c.id===m.character))p.character=m.character;p.ready=false;}
 if(m.type==='ready'&&room.phase==='lobby')p.ready=m.ready===true;
 if(m.type==='chat'){
 if(room.phase!=='lobby'||room.practice)return error('El chat está disponible en la sala de amigos antes de correr.');
 if(typeof m.text!=='string'||m.text.length>240)return error('El mensaje admite hasta 240 caracteres.');
 const text=m.text.replace(/[\u0000-\u001f\u007f\u202a-\u202e\u2066-\u2069]/g,' ').trim();if(!text)return;
 const now=Date.now();if(now-(p.lastChatAt||0)<1200)return error('Espera un momento antes de enviar otro mensaje.');p.lastChatAt=now;
 room.chat=(room.chat||[]).filter(c=>now-c.at<600000);room.chat.push({id:uid(),sender:p.id,name:p.name,text,at:now});room.chat=room.chat.slice(-40);
 for(const q of room.players)if(q.connected&&q.ws)send(q.ws,{type:'chat',messages:room.chat});return;
 }
 if(m.type==='config'&&p.id===room.host&&room.phase==='lobby'){if(Array.isArray(m.tracks)&&m.tracks.length>=1&&m.tracks.length<=3&&m.tracks.every(id=>TRACKS.some(t=>t.id===id&&(id!=='calibracion'||process.env.NODE_ENV!=='production')))){room.mode=m.mode==='cup'?'cup':'race';if(room.mode==='cup'&&m.tracks.length!==3)return error('Selecciona tres pistas para la copa.');room.tracks=room.mode==='cup'?m.tracks:[m.tracks[0]];room.track=room.tracks[0];room.round=0;for(const q of room.players)q.ready=false;}}
 if(m.type==='rotate'&&p.id===room.host&&room.phase==='lobby'){rooms.delete(room.code);room.code=randomBytes(7).toString('hex').toUpperCase();rooms.set(room.code,room);for(const q of room.players)if(q.ws)q.ws.room=room.code;}
 if(m.type==='start'&&p.id===room.host&&room.phase==='lobby'){const active=room.players.filter(q=>q.connected);if(active.length<(room.practice?1:2))return error('Invita al menos a otra persona.');if(active.some(q=>!q.ready))return error('Falta que todos estén listos.');for(const q of room.players)q.points=0;room.round=0;startRace(room);}
 if(m.type==='next'&&p.id===room.host&&room.phase==='results'){if(room.mode==='cup'&&room.round<2){room.round++;startRace(room);}else{room.round=0;for(const q of room.players)q.points=0;startRace(room);}}
 if(m.type==='lobby'&&p.id===room.host&&room.phase==='results'){room.phase='lobby';room.round=0;for(const q of room.players){q.kart=null;q.ready=false;q.spectator=false;}}
 if(m.type==='tune'&&room.practice&&process.env.NODE_ENV!=='production'&&['suave','equilibrado','agil'].includes(m.tune))room.tune=m.tune;
 broadcast(room);
 }catch{send(ws,{type:'error',message:'Solicitud inválida.'});}});
 ws.on('close',()=>detach(ws));ws.on('error',()=>{});
});
let last=performance.now(),acc=0,ticks=0;const loop=setInterval(()=>{const now=performance.now();acc+=Math.min(.2,(now-last)/1000);last=now;while(acc>=DT){for(const r of rooms.values()){const phase=r.phase;tickRace(r);if(phase!==r.phase&&r.phase==='results')broadcast(r);}acc-=DT;ticks++;if(ticks%3===0)for(const r of rooms.values())if(['countdown','race'].includes(r.phase))broadcast(r);}},8);
const cleanup=setInterval(()=>{const now=Date.now();for(const r of rooms.values()){const chatCount=(r.chat||[]).length;r.chat=(r.chat||[]).filter(c=>now-c.at<600000);if(r.chat.length!==chatCount)for(const q of r.players)if(q.connected&&q.ws)send(q.ws,{type:'chat',messages:r.chat});r.players=r.players.filter(p=>p.connected||now-p.leftAt<30000||(['race','results'].includes(r.phase)&&p.kart));if(!r.players.some(p=>p.connected)&&now-r.lastActive>60000||now-r.lastActive>600000){for(const p of r.players)if(p.ws)p.ws.close(1000,'Sala cerrada por inactividad');rooms.delete(r.code);}else transfer(r);}for(const ws of wss.clients){if(ws.isAlive===false){ws.terminate();continue;}ws.isAlive=false;ws.ping();}},15000);
server.listen(PORT,HOST,()=>console.log(`CARPOREO listo: http://${HOST}:${PORT}`));
function shutdown(){clearInterval(loop);clearInterval(cleanup);for(const ws of wss.clients)ws.close(1001,'Servidor reiniciando');wss.close();server.close();setTimeout(()=>process.exit(0),200).unref();}process.on('SIGTERM',shutdown);process.on('SIGINT',shutdown);
