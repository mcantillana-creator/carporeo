// Original composition: brisk pentatonic arpeggios, pulse lead and triangle bass.
// No recordings, melody transcriptions or samples from commercial games.
export const MUSIC_TEMPO={normal:144,final:198};
export function musicNotes(beat,track='santiago'){
 const variant={santiago:0,pacifico:2,cordillera:1,tololo:3,atacama:4}[track]||0;
 const roots=[50,46,53,48],root=roots[Math.floor(beat/16)%4];
 const pattern=[0,7,12,14,7,19,12,7,3,12,19,14,10,7,12,3];
 return {lead:root+12+pattern[(beat+variant*2)%pattern.length],bass:root-12,chord:[root,root+7,root+14],accent:beat%4===0};
}
export function createAudio(settings){return {
 ctx:null,nextBeat:0,beat:0,lastLap:null,lastEmote:null,urgentAt:0,
 tone(midi,time,duration,volume,type='triangle',bus){if(!this.ctx)return;const o=this.ctx.createOscillator(),g=this.ctx.createGain();o.type=type;o.frequency.value=440*2**((midi-69)/12);o.connect(g);g.connect(bus||this.ctx.destination);g.gain.setValueAtTime(.0001,time);g.gain.linearRampToValueAtTime(volume,time+.02);g.gain.exponentialRampToValueAtTime(.0001,time+duration);o.start(time);o.stop(time+duration+.02);o.onended=()=>{o.disconnect();g.disconnect();};},
 cue(kind){if(!this.ctx||!settings.sfx||this.ctx.state!=='running')return;const t=this.ctx.currentTime;
 const notes=kind==='lastlap'?[76,79,83,88]:kind==='happy'?[72,79,84]:kind==='hurt'?[61,55]:kind==='pickup'?[79,86]:kind==='go'?[83,88]:[69];
 notes.forEach((n,i)=>this.tone(n,t+i*.11,.2,.045,'square'));},
 start(){try{if(!this.ctx){this.ctx=new AudioContext();this.gain=this.ctx.createGain();this.gain.gain.value=0;this.gain.connect(this.ctx.destination);this.osc=this.ctx.createOscillator();this.osc.type='triangle';this.osc.connect(this.gain);this.osc.start();this.musicGain=this.ctx.createGain();this.musicGain.gain.value=0;this.musicGain.connect(this.ctx.destination);}if(this.ctx.state==='suspended')this.ctx.resume();}catch{}},
 resetRace(){this.beat=0;this.nextBeat=this.ctx?.currentTime||0;this.lastLap=null;this.lastEmote=null;this.urgentAt=0;},
 update(k,track){if(!this.ctx||!k||this.ctx.state!=='running')return;const now=this.ctx.currentTime;
 this.osc.frequency.setTargetAtTime(60+k.speed*4+(k.drift||0)*12,now,.08);this.gain.gain.setTargetAtTime(settings.sfx&&!k.finished?.018:0,now,.08);
 this.musicGain.gain.setTargetAtTime(settings.music&&!k.finished?.5:0,now,.1);
 if(k.lap===2&&this.lastLap!==2){this.cue('lastlap');this.urgentAt=now+6;}this.lastLap=k.lap;
 if(k.lap===2&&!k.finished&&now>=this.urgentAt){this.cue('count');this.urgentAt=now+6;}
 const emote=k.emoteTime>0?k.emote:null;if(emote&&emote!==this.lastEmote)this.cue(emote);this.lastEmote=emote;
 if(this.nextBeat<now-.2)this.nextBeat=now;
 const step=60/(k.lap===2?MUSIC_TEMPO.final:MUSIC_TEMPO.normal)/2;
 while(this.nextBeat<now+.12){const t=this.nextBeat,n=musicNotes(this.beat,track);
 if(settings.music&&!k.finished){this.tone(n.lead,t,step*.85,.05,'square',this.musicGain);if(n.accent)this.tone(n.bass,t,step*1.7,.12,'triangle',this.musicGain);
 if(this.beat%8===0)n.chord.forEach((pitch,i)=>this.tone(pitch,t+i*.02,step*3,.022,'triangle',this.musicGain));}
 this.beat++;this.nextBeat+=step;
 }
 },
 quiet(){if(this.ctx){this.gain.gain.setTargetAtTime(0,this.ctx.currentTime,.1);this.musicGain.gain.setTargetAtTime(0,this.ctx.currentTime,.1);}}
};}
