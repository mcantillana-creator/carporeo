import {at,project,clamp,mod,angle,hazards,hazardState,rampZones,gaps,gapAt,obstacles,outwardAcceleration} from './tracks.js';
export const DT=1/60;
export const ayudasActivas=true; // Default; every room owns its independent override.
export const TUNES={suave:{maxSpeed:42,accel:.68,turn:1.55,grip:9},equilibrado:{maxSpeed:48,accel:.68,turn:1.85,grip:8},agil:{maxSpeed:52,accel:.73,turn:2.05,grip:7}};
export const CONFIG={brake:32,coast:.55,driftGrip:2.6,gravity:18,boostScale:1.25,boostSeconds:1.8,offroadScale:.66,jumpSpeed:11,jumpCooldown:1.3,respawnDelay:.9};
export function spawn(tr,slot=0){const p=at(tr,12-Math.floor(slot/4)*5),lane=((slot%4)-1.5)*4;return {x:p.x+p.nx*lane,z:p.z+p.nz*lane,y:p.y,yaw:p.yaw,vx:0,vz:0,vy:0,s:p.s,lastS:p.s,gate:1,lap:0,progress:p.s,speed:0,boost:0,shield:0,club:0,auto:0,cloud:0,immune:0,drift:0,air:0,wrong:0,finished:false,finishTime:null,power:null,pickup:0,bump:0,rampCooldown:0,jumpCooldown:0,recovery:0,recoveries:0,safe:{s:p.s,gate:1,lap:0},falling:false,fallTime:0,emote:null,emoteTime:0};}
export function resetKart(k,tr){const s=mod((k.gate===0?11:k.gate-1)*tr.length/12+2,tr.length),p=at(tr,s);Object.assign(k,{x:p.x,z:p.z,y:p.y,yaw:p.yaw,vx:0,vz:0,vy:0,s,lastS:s,immune:2,air:0,wrong:0});}
export function recoverKart(k,tr,reason='caída'){
 const safe=k.safe||{s:12,gate:1,lap:0},p=at(tr,safe.s);
 Object.assign(k,{x:p.x,z:p.z,y:p.y,yaw:p.yaw,vx:0,vz:0,vy:0,s:p.s,lastS:p.s,speed:0,gate:safe.gate,lap:safe.lap,air:0,falling:false,fallTime:0,recovery:0,immune:2,wrong:0,recoveries:(k.recoveries||0)+1,recoveryReason:reason});
 k.progress=k.lap*tr.length+k.s;
}
export function beginFall(k,reason='caída'){
 if(k.falling)return;k.falling=true;k.fallTime=CONFIG.respawnDelay;k.air=1;k.vy=Math.min(0,k.vy);k.recoveryReason=reason;k.emote='hurt';k.emoteTime=1.2;
}
export function collideKarts(x,y){
 if(x.falling||y.falling||x.recovery>0||y.recovery>0||Math.abs(x.y-y.y)>=2)return;
 let dx=x.x-y.x,dz=x.z-y.z,d=Math.hypot(dx,dz);if(d>=2.1)return;
 if(d<.001){dx=1;dz=0;d=1;}const nx=dx/d,nz=dz/d,push=Math.max(0,(2.1-d)*.5);
 x.x+=nx*push;x.z+=nz*push;y.x-=nx*push;y.z-=nz*push;
 const closing=Math.max(0,-((x.vx-y.vx)*nx+(x.vz-y.vz)*nz));
 if(closing>1){const impulse=Math.min(4.5,closing*.3);x.vx+=nx*impulse;x.vz+=nz*impulse;y.vx-=nx*impulse;y.vz-=nz*impulse;
 for(const k of [x,y]){k.speed=Math.hypot(k.vx,k.vz);k.emote='hurt';k.emoteTime=.9;k.bump=.35;}}
}
export function sanitizeInput(i){return {steer:clamp(Number(i.steer)||0,-1,1),throttle:clamp(Number(i.throttle)||0,0,1),brake:i.brake===true,drift:i.drift===true,use:i.use===true,reset:i.reset===true,jump:i.jump===true};}
export function step(k,input,tr,dt=DT,tune='equilibrado',clock=0,ayudas=ayudasActivas){
 if(k.finished)return;k.clock=clock;
 const t=TUNES[tune]||TUNES.equilibrado,i=sanitizeInput(input),oldS=k.s;
 for(const key of ['boost','shield','club','auto','cloud','immune','pickup','bump','rampCooldown','jumpCooldown','recovery','emoteTime'])k[key]=Math.max(0,k[key]-dt);
 if(i.reset){resetKart(k,tr);k.falling=false;k.fallTime=0;return;}if(k.falling){k.fallTime=Math.max(0,k.fallTime-dt);k.vy-=CONFIG.gravity*dt;k.y+=k.vy*dt;k.x+=k.vx*dt;k.z+=k.vz*dt;if(k.fallTime<1e-8)recoverKart(k,tr,k.recoveryReason);return;}if(k.recovery>0)return;
 let p=project(tr,k.x,k.z),speed=Math.hypot(k.vx,k.vz),steer=i.steer;
 if(k.auto>0){if(gaps(tr).some(g=>g.start-k.s>0&&g.start-k.s<Math.max(5,speed*.18)))i.jump=true;const ahead=at(tr,p.s+12+speed*.3),desired=Math.atan2(ahead.x-k.x,ahead.z-k.z);steer=clamp(-angle(desired-k.yaw)*2.2,-1,1);i.throttle=1;i.brake=false;}
 const offroad=Math.abs(p.offset)>tr.width/2,icy=tr.id==='cordillera'&&mod(p.s/tr.length,1)>.37&&p.s/tr.length<.47;
 const isDrift=i.drift&&Math.abs(steer)>.18&&speed>9;
 k.drift+=((isDrift?1:0)-k.drift)*Math.min(1,dt*9);
 const cornerLoad=clamp(Math.abs(steer)*speed/t.maxSpeed,0,1);
 const powerOversteer=!k.air?Math.max(0,i.throttle-.65)*cornerLoad:0;
 // TCS limits drive torque under cornering load; ESP retains lateral stability.
 const traction=ayudas?1-.45*powerOversteer:1;
 const oversteer=ayudas?0:powerOversteer*.8;
 const turn=t.turn*(.5+.5*clamp(speed/12,0,1))*(1-.27*clamp(speed/t.maxSpeed,0,1));
 k.yaw-=steer*turn*clamp(speed/3,0,1)*(1+k.drift*.28+oversteer)*dt;
 const fx=Math.sin(k.yaw),fz=Math.cos(k.yaw),rx=fz,rz=-fx;
 let forward=k.vx*fx+k.vz*fz,lateral=k.vx*rx+k.vz*rz;
 const cap=t.maxSpeed*(k.boost>0?CONFIG.boostScale:1)*(k.club>0?1.08:1)*(k.auto>0?1.18:1)*(offroad?CONFIG.offroadScale:1);
 if(i.brake&&!i.drift)forward=Math.max(0,forward-CONFIG.brake*dt);
 else if(i.throttle>0)forward+=(cap*i.throttle-forward)*t.accel*traction*dt;
 else forward*=Math.exp(-CONFIG.coast*dt);
 if(i.drift)forward*=Math.exp(-.08*dt);
 const grip=(t.grip*(1-k.drift)+CONFIG.driftGrip*k.drift)*(icy?.62:1)*(ayudas?1:1-.5*cornerLoad-.3*powerOversteer);
 lateral*=Math.exp(-grip*dt);
 k.vx=fx*forward+rx*lateral;k.vz=fz*forward+rz*lateral;
 if(!k.air){const bank=outwardAcceleration(tr,p.s,speed);k.vx+=bank.nx*bank.force*dt;k.vz+=bank.nz*bank.force*dt;}
 k.x+=k.vx*dt;k.z+=k.vz*dt;
 p=project(tr,k.x,k.z);
 if(i.jump&&!k.air&&Math.abs(p.offset)<=14&&!gapAt(tr,oldS)&&k.jumpCooldown===0){k.vy=CONFIG.jumpSpeed;k.air=1;k.jumpCooldown=CONFIG.jumpCooldown;}
 const ramp=rampZones(tr).some(q=>p.s/tr.length>q&&p.s/tr.length<q+.006);
 if(ramp&&!k.air&&k.rampCooldown===0&&speed>12){k.vy=11;k.air=1;k.rampCooldown=3;}
 const gap=gapAt(tr,p.s)||Math.abs(p.offset)>14;
 if(gap&&!k.air){beginFall(k);return;}
 if(k.air){k.vy-=CONFIG.gravity*dt;k.y+=k.vy*dt;
 if(!gap&&k.y>=p.y-.5&&k.y<=p.y+.05&&k.vy<=0){k.y=p.y;k.vy=0;k.air=0;k.falling=false;}
 else if(k.y<p.y-.5){beginFall(k);return;}
 }else k.y=p.y;
 

 // Resolve hazards here so prediction and authoritative simulation agree.
 for(const h of hazards(tr)){
 const state=hazardState(h,clock),dx=k.x-h.x,dz=k.z-h.z;
 const lateral=dx*h.nx+dz*h.nz,along=dx*h.tx+dz*h.tz;
 if(Math.abs(lateral)<h.width/2+.8&&Math.abs(along)<h.depth/2+1&&k.y<h.y+state.lift+h.height&&k.y+1.5>h.y+state.lift){
 if(h.kind==='drop'&&state.falling&&k.immune<=0){beginFall(k,'aplastamiento');return;}
 const side=along<0?-1:1,push=side*(h.depth/2+1)-along;
 k.x+=h.tx*push;k.z+=h.tz*push;
 const v=k.vx*h.tx+k.vz*h.tz;
 if(v*side<0){k.vx-=h.tx*v;k.vz-=h.tz*v;}
 hit(k,.25);
 }
 }
 for(const o of obstacles(tr)){const dx=k.x-o.x,dz=k.z-o.z,d=Math.hypot(dx,dz),min=o.r+1;if(d<min&&k.y<o.y+2){const nx=d>.001?dx/d:1,nz=d>.001?dz/d:0;k.x+=nx*(min-d);k.z+=nz*(min-d);hit(k);}}
 p=project(tr,k.x,k.z);
 k.speed=Math.hypot(k.vx,k.vz);k.s=p.s;
 const delta=mod(k.s-oldS+tr.length/2,tr.length)-tr.length/2;
 k.wrong=delta<-.015?Math.min(2,k.wrong+dt):Math.max(0,k.wrong-dt*2);
 // Only nearby, forward physical crossings can advance a checkpoint.
 const gateS=k.gate*tr.length/12,dist=mod(gateS-oldS,tr.length);
 if(!k.falling&&delta>0&&delta<Math.max(3,k.speed*dt+1)&&dist<=delta+.001){if(k.gate===0){k.lap++;if(k.lap>=tr.laps){k.finished=true;k.finishTime=clock;}}k.gate=(k.gate+1)%12;}
 k.progress=k.lap*tr.length+(k.gate===0?Math.max(11*tr.length/12,k.s):Math.min(k.s,k.gate*tr.length/12));
 if(!k.air&&Math.abs(p.offset)<10.5&&!gapAt(tr,k.s,48)&&!hazards(tr).some(h=>h.kind==='drop'&&Math.abs(h.s-k.s)<20))k.safe={s:k.s,gate:k.gate,lap:k.lap};
 if(!Number.isFinite(k.x)||Math.abs(k.y)>500)resetKart(k,tr);
}
export function hit(k,seconds=.45){if(k.immune>0||k.club>0||k.auto>0)return false;if(k.shield>0){k.shield=0;k.immune=1;return false;}k.vx*=.55;k.vz*=.55;k.speed=Math.hypot(k.vx,k.vz);k.immune=1.5;k.bump=seconds;k.emote='hurt';k.emoteTime=1;return true;}
export const POWERS=[{id:'fibra',name:'Fibra Óptica',icon:'↗',color:'#21d7ff'},{id:'telefono',name:'Teléfono',icon:'▣',color:'#ffb75b'},{id:'bolsa',name:'Bolsa de Datos',icon:'＋',color:'#64e8ab'},{id:'club',name:'Club Entel',icon:'★',color:'#ffd85a'},{id:'5g',name:'5G',icon:'5G',color:'#cf95ff'},{id:'vpn',name:'VPN',icon:'⬡',color:'#6ecaff'},{id:'nube',name:'La Nube',icon:'☁',color:'#e4eaff'}];
