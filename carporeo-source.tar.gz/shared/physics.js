import {at,project,clamp,mod,angle,hazards,hazardState,rampZones} from './tracks.js';
export const DT=1/60;
export const TUNES={suave:{maxSpeed:30,accel:.68,turn:1.25,grip:9},equilibrado:{maxSpeed:34,accel:.68,turn:1.5,grip:8},agil:{maxSpeed:36,accel:.73,turn:1.7,grip:7}};
export const CONFIG={brake:24,coast:.55,driftGrip:2.6,gravity:22,boostScale:1.25,boostSeconds:1.8,offroadScale:.66,jumpSpeed:6.5,jumpCooldown:.75};
export function spawn(tr,slot=0){const p=at(tr,12-Math.floor(slot/4)*5),lane=((slot%4)-1.5)*4;return {x:p.x+p.nx*lane,z:p.z+p.nz*lane,y:p.y,yaw:p.yaw,vx:0,vz:0,vy:0,s:p.s,lastS:p.s,gate:1,lap:0,progress:p.s,speed:0,boost:0,shield:0,club:0,auto:0,cloud:0,immune:0,drift:0,air:0,wrong:0,finished:false,finishTime:null,power:null,pickup:0,bump:0,rampCooldown:0,jumpCooldown:0};}
export function resetKart(k,tr){const s=mod((k.gate===0?11:k.gate-1)*tr.length/12+2,tr.length),p=at(tr,s);Object.assign(k,{x:p.x,z:p.z,y:p.y,yaw:p.yaw,vx:0,vz:0,vy:0,s,lastS:s,immune:2,air:0,wrong:0});}
export function sanitizeInput(i){return {steer:clamp(Number(i.steer)||0,-1,1),throttle:clamp(Number(i.throttle)||0,0,1),brake:i.brake===true,drift:i.drift===true,use:i.use===true,reset:i.reset===true,jump:i.jump===true};}
export function step(k,input,tr,dt=DT,tune='equilibrado',clock=0){
 if(k.finished)return;
 const t=TUNES[tune]||TUNES.equilibrado,i=sanitizeInput(input),oldS=k.s;
 for(const key of ['boost','shield','club','auto','cloud','immune','pickup','bump','rampCooldown','jumpCooldown'])k[key]=Math.max(0,k[key]-dt);
 if(i.reset){resetKart(k,tr);return;}
 let p=project(tr,k.x,k.z),speed=Math.hypot(k.vx,k.vz),steer=i.steer;
 if(k.auto>0){const ahead=at(tr,p.s+12+speed*.3),desired=Math.atan2(ahead.x-k.x,ahead.z-k.z);steer=clamp(-angle(desired-k.yaw)*2.2,-1,1);i.throttle=1;i.brake=false;}
 const offroad=Math.abs(p.offset)>tr.width/2,icy=tr.id==='cordillera'&&mod(p.s/tr.length,1)>.37&&p.s/tr.length<.47;
 const isDrift=i.drift&&Math.abs(steer)>.18&&speed>9;
 k.drift+=((isDrift?1:0)-k.drift)*Math.min(1,dt*9);
 const turn=t.turn*(.5+.5*clamp(speed/12,0,1))*(1-.27*clamp(speed/t.maxSpeed,0,1));
 k.yaw-=steer*turn*clamp(speed/3,0,1)*(1+k.drift*.28)*dt;
 const fx=Math.sin(k.yaw),fz=Math.cos(k.yaw),rx=fz,rz=-fx;
 let forward=k.vx*fx+k.vz*fz,lateral=k.vx*rx+k.vz*rz;
 const cap=t.maxSpeed*(k.boost>0?CONFIG.boostScale:1)*(k.club>0?1.08:1)*(k.auto>0?1.18:1)*(offroad?CONFIG.offroadScale:1);
 if(i.brake&&!i.drift)forward=Math.max(0,forward-CONFIG.brake*dt);
 else if(i.throttle>0)forward+=(cap*i.throttle-forward)*t.accel*dt;
 else forward*=Math.exp(-CONFIG.coast*dt);
 if(i.drift)forward*=Math.exp(-.08*dt);
 const grip=(t.grip*(1-k.drift)+CONFIG.driftGrip*k.drift)*(icy?.62:1);
 lateral*=Math.exp(-grip*dt);
 k.vx=fx*forward+rx*lateral;k.vz=fz*forward+rz*lateral;
 k.x+=k.vx*dt;k.z+=k.vz*dt;
 p=project(tr,k.x,k.z);
 const limit=tr.width/2+1.8;
 if(Math.abs(p.offset)>limit){const side=Math.sign(p.offset),d=p.offset-side*limit;k.x-=p.nx*d;k.z-=p.nz*d;const outward=(k.vx*p.nx+k.vz*p.nz)*side;if(outward>0){k.vx-=p.nx*outward*side;k.vz-=p.nz*outward*side;}if(!k.bump){k.vx*=.88;k.vz*=.88;k.bump=.5;}const target=Math.atan2(p.tx,p.tz);k.yaw+=angle(target-k.yaw)*Math.min(1,dt*1.8);}
 if(i.jump&&!k.air&&k.jumpCooldown===0){k.vy=CONFIG.jumpSpeed;k.air=1;k.jumpCooldown=CONFIG.jumpCooldown;}
 const ramp=rampZones(tr).some(q=>p.s/tr.length>q&&p.s/tr.length<q+.006);
 if(ramp&&!k.air&&k.rampCooldown===0&&speed>12){k.vy=5.5;k.air=1;k.rampCooldown=3;}
 if(k.air){k.vy-=CONFIG.gravity*dt;k.y+=k.vy*dt;if(k.y<=p.y){k.y=p.y;k.vy=0;k.air=0;}}else k.y=p.y;
 // Resolve hazards here so prediction and authoritative simulation agree.
 for(const h of hazards(tr)){
 const state=hazardState(h,clock),dx=k.x-h.x,dz=k.z-h.z;
 const lateral=dx*h.nx+dz*h.nz,along=dx*h.tx+dz*h.tz;
 if(Math.abs(lateral)<h.width/2+.8&&Math.abs(along)<h.depth/2+1&&k.y<h.y+state.lift+h.height&&k.y+1.5>h.y+state.lift){
 const side=along<0?-1:1,push=side*(h.depth/2+1)-along;
 k.x+=h.tx*push;k.z+=h.tz*push;
 const v=k.vx*h.tx+k.vz*h.tz;
 if(v*side<0){k.vx-=h.tx*v;k.vz-=h.tz*v;}
 hit(k,.25);
 }
 }
 p=project(tr,k.x,k.z);
 k.speed=Math.hypot(k.vx,k.vz);k.s=p.s;
 const delta=mod(k.s-oldS+tr.length/2,tr.length)-tr.length/2;
 k.wrong=delta<-.015?Math.min(2,k.wrong+dt):Math.max(0,k.wrong-dt*2);
 // Only nearby, forward physical crossings can advance a checkpoint.
 const gateS=k.gate*tr.length/12,dist=mod(gateS-oldS,tr.length);
 if(delta>0&&delta<Math.max(3,k.speed*dt+1)&&dist<=delta+.001){if(k.gate===0){k.lap++;if(k.lap>=tr.laps){k.finished=true;k.finishTime=clock;}}k.gate=(k.gate+1)%12;}
 k.progress=k.lap*tr.length+(k.gate===0?Math.max(11*tr.length/12,k.s):Math.min(k.s,k.gate*tr.length/12));
 if(!Number.isFinite(k.x)||Math.abs(k.y)>500)resetKart(k,tr);
}
export function hit(k,seconds=.45){if(k.immune>0||k.club>0||k.auto>0)return false;if(k.shield>0){k.shield=0;k.immune=1;return false;}k.vx*=.55;k.vz*=.55;k.immune=1.5;k.bump=seconds;return true;}
export const POWERS=[{id:'fibra',name:'Fibra Óptica',icon:'↗',color:'#21d7ff'},{id:'telefono',name:'Teléfono',icon:'▣',color:'#ffb75b'},{id:'bolsa',name:'Bolsa de Datos',icon:'＋',color:'#64e8ab'},{id:'club',name:'Club Entel',icon:'★',color:'#ffd85a'},{id:'5g',name:'5G',icon:'5G',color:'#cf95ff'},{id:'vpn',name:'VPN',icon:'⬡',color:'#6ecaff'},{id:'nube',name:'La Nube',icon:'☁',color:'#e4eaff'}];
