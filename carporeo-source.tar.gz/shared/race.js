import {buildTrack,boxes,obstacles,at,angle,clamp,hazards,mod,gaps,project,hazardState} from './tracks.js';
import {spawn,step,hit,POWERS,DT,collideKarts} from './physics.js';
export const POINTS=[12,10,8,6,4,3,2,1];
export function startRace(room){const tr=buildTrack(room.tracks[room.round]||'santiago');room.track=tr.id;room.phase='countdown';room.time=-3;room.finishDeadline=210;room.shots=[];room.boxes=boxes(tr).map(b=>({...b,cooldown:0,brokenAt:null,brokenBy:null}));let slot=0;for(const p of room.players){p.spectator=!p.connected;p.kart=p.spectator?null:spawn(tr,slot++);p.queue=[];p.lastInput={};p.ack=0;p.seq=0;p.ready=false;p.place=null;}room.entries=room.players.filter(p=>p.kart).map(p=>p.id);}
export function ranking(room){return room.players.filter(p=>p.kart).sort((a,b)=>{const x=a.kart,y=b.kart;if(x.finished&&y.finished)return x.finishTime-y.finishTime||a.id.localeCompare(b.id);if(x.finished)return -1;if(y.finished)return 1;return y.progress-x.progress||a.id.localeCompare(b.id);});}
export function usePower(room,p){const k=p.kart;if(!k?.power||k.finished)return;const pow=k.power;k.power=null;if(['fibra','bolsa','club','5g'].includes(pow)){k.emote='happy';k.emoteTime=1.5;}
 if(pow==='fibra')k.boost=1.8;if(pow==='bolsa')k.boost=.85;if(pow==='vpn')k.shield=8;if(pow==='club'){k.club=3;k.boost=1;}if(pow==='5g'){k.auto=2.2;k.immune=2.2;}if(pow==='nube')for(const q of room.players)if(q!==p&&q.kart&&!q.kart.finished&&q.kart.club<=0&&q.kart.shield<=0)q.kart.cloud=4;
 if(pow==='telefono'){const target=room.players.filter(q=>q!==p&&q.kart&&!q.kart.finished&&mod(q.kart.s-k.s,buildTrack(room.track).length)<180).sort((a,b)=>mod(a.kart.s-k.s,buildTrack(room.track).length)-mod(b.kart.s-k.s,buildTrack(room.track).length))[0];room.shots.push({target:target?.id,owner:p.id,x:k.x+Math.sin(k.yaw)*3,z:k.z+Math.cos(k.yaw)*3,y:k.y+1,vx:Math.sin(k.yaw)*78,vz:Math.cos(k.yaw)*78,life:4});}
}
export function finishRace(room){if(room.phase==='results')return;room.phase='results';ranking(room).forEach((p,i)=>{p.place=i+1;const points=p.kart.finished?(POINTS[i]||0):0;p.points=(p.points||0)+points;p.lastPoints=points;});}
export function tickRace(room,dt=DT){if(!['countdown','race'].includes(room.phase))return;room.time+=dt;if(room.time<0)return;if(room.phase==='countdown')room.phase='race';const tr=buildTrack(room.track);
 for(const p of room.players){if(!p.kart||p.kart.finished)continue;let cmd=p.queue.shift();if(cmd){p.ack=cmd.seq;p.lastInput=cmd.input;}let input=p.connected?{...p.lastInput}:{};if(cmd&&input.use)usePower(room,p);if(!cmd){input.use=false;input.reset=false;input.jump=false;}
 step(p.kart,input,tr,dt,room.tune||'equilibrado',room.time,room.ayudasActivas!==false);

 if(p.kart.finished&&room.finishDeadline===210)room.finishDeadline=Math.min(210,room.time+35);
 }
 const active=room.players.filter(p=>p.kart&&!p.kart.finished);
 for(let a=0;a<active.length;a++)for(let b=a+1;b<active.length;b++)collideKarts(active[a].kart,active[b].kart);
 for(const b of room.boxes){b.cooldown=Math.max(0,b.cooldown-dt);if(b.cooldown)continue;for(const p of active){const k=p.kart;if(!k.falling&&Math.abs(k.y-b.y)<2.5&&Math.hypot(k.x-b.x,k.z-b.z)<2.8){const rank=ranking(room).findIndex(q=>q.id===p.id),pool=rank>1?['fibra','fibra','5g','club','bolsa','vpn','nube','telefono']:['telefono','vpn','bolsa','fibra','nube'];if(!k.power&&k.pickup<=0){k.power=pool[Math.floor(Math.random()*pool.length)];k.pickup=1;}b.cooldown=5;b.brokenAt=room.time;b.brokenBy=p.id;break;}}}
 for(const s of room.shots){const target=active.find(p=>p.id===s.target)?.kart;
 if(target){const d=Math.hypot(target.x-s.x,target.z-s.z);if(d>0){const desired=Math.atan2(target.x-s.x,target.z-s.z),yaw=Math.atan2(s.vx,s.vz),turn=clamp(angle(desired-yaw),-5*dt,5*dt);s.vx=Math.sin(yaw+turn)*78;s.vz=Math.cos(yaw+turn)*78;s.y+=(target.y+1-s.y)*Math.min(1,dt*8);}}
 s.x+=s.vx*dt;s.z+=s.vz*dt;s.life-=dt;for(const p of active)if(p.id!==s.owner&&Math.hypot(p.kart.x-s.x,p.kart.z-s.z)<2.2&&Math.abs(p.kart.y+1-s.y)<3){hit(p.kart);s.life=0;break;}}
 room.shots=room.shots.filter(s=>s.life>0);
 if(room.time>=room.finishDeadline||room.players.filter(p=>p.kart).every(p=>p.kart.finished))finishRace(room);
}
export function drivingBot(k,tr){const look=at(tr,k.s+10+k.speed*.35);let lane=0;const upcoming=hazards(tr).filter(h=>h.kind==='drop'&&h.s-k.s>-8&&h.s-k.s<65);if(upcoming.length){const arrival=(k.clock||0)+Math.max(0,upcoming[0].s-k.s)/Math.max(14,k.speed);const chosen=upcoming.reduce((a,b)=>hazardState(a,arrival).lift>hazardState(b,arrival).lift?a:b);lane=chosen.id.endsWith('-1')?6:-6;}const desired=Math.atan2(look.x+look.nx*lane-k.x,look.z+look.nz*lane-k.z),error=angle(desired-k.yaw);return {steer:clamp(-error*2.4,-1,1),throttle:Math.abs(error)>.8?.6:1,brake:false,jump:!k.air&&(hazards(tr).some(h=>h.kind==='hurdle'&&mod(h.s-k.s,tr.length)<Math.max(5,k.speed*.2))||gaps(tr).some(g=>g.start-k.s>0&&g.start-k.s<Math.max(4,k.speed*.15)))};}
