import {buildTrack,boxes,obstacles,at,angle,clamp} from './tracks.js';
import {spawn,step,hit,POWERS,DT} from './physics.js';
export const POINTS=[12,10,8,6,4,3,2,1];
export function startRace(room){const tr=buildTrack(room.tracks[room.round]||'santiago');room.track=tr.id;room.phase='countdown';room.time=-3;room.finishDeadline=210;room.shots=[];room.boxes=boxes(tr).map(b=>({...b,cooldown:0,brokenAt:null,brokenBy:null}));let slot=0;for(const p of room.players){p.spectator=!p.connected;p.kart=p.spectator?null:spawn(tr,slot++);p.queue=[];p.lastInput={};p.ack=0;p.seq=0;p.ready=false;p.place=null;}room.entries=room.players.filter(p=>p.kart).map(p=>p.id);}
export function ranking(room){return room.players.filter(p=>p.kart).sort((a,b)=>{const x=a.kart,y=b.kart;if(x.finished&&y.finished)return x.finishTime-y.finishTime||a.id.localeCompare(b.id);if(x.finished)return -1;if(y.finished)return 1;return y.progress-x.progress||a.id.localeCompare(b.id);});}
export function usePower(room,p){const k=p.kart;if(!k?.power||k.finished)return;const pow=k.power;k.power=null;
 if(pow==='fibra')k.boost=1.8;if(pow==='bolsa')k.boost=.85;if(pow==='vpn')k.shield=8;if(pow==='club'){k.club=3;k.boost=1;}if(pow==='5g'){k.auto=2.2;k.immune=2.2;}if(pow==='nube')for(const q of room.players)if(q!==p&&q.kart&&!q.kart.finished&&q.kart.club<=0&&q.kart.shield<=0)q.kart.cloud=2;
 if(pow==='telefono')room.shots.push({owner:p.id,x:k.x+Math.sin(k.yaw)*3,z:k.z+Math.cos(k.yaw)*3,y:k.y+1,vx:Math.sin(k.yaw)*58,vz:Math.cos(k.yaw)*58,life:2});
}
export function finishRace(room){if(room.phase==='results')return;room.phase='results';ranking(room).forEach((p,i)=>{p.place=i+1;const points=p.kart.finished?(POINTS[i]||0):0;p.points=(p.points||0)+points;p.lastPoints=points;});}
export function tickRace(room,dt=DT){if(!['countdown','race'].includes(room.phase))return;room.time+=dt;if(room.time<0)return;if(room.phase==='countdown')room.phase='race';const tr=buildTrack(room.track);
 for(const p of room.players){if(!p.kart||p.kart.finished)continue;let cmd=p.queue.shift();if(cmd){p.ack=cmd.seq;p.lastInput=cmd.input;}let input=p.connected?{...p.lastInput}:{};if(cmd&&input.use)usePower(room,p);if(!cmd){input.use=false;input.reset=false;input.jump=false;}
 step(p.kart,input,tr,dt,room.tune||'equilibrado',room.time);
 for(const o of obstacles(tr)){let dx=p.kart.x-o.x,dz=p.kart.z-o.z,d=Math.hypot(dx,dz),min=o.r+1;if(d<min){if(d<.001){dx=1;dz=0;d=1;}p.kart.x+=dx/d*(min-d);p.kart.z+=dz/d*(min-d);hit(p.kart);}}
 if(p.kart.finished&&room.finishDeadline===210)room.finishDeadline=Math.min(210,room.time+35);
 }
 const active=room.players.filter(p=>p.kart&&!p.kart.finished);
 for(let a=0;a<active.length;a++)for(let b=a+1;b<active.length;b++){let x=active[a].kart,y=active[b].kart,dx=x.x-y.x,dz=x.z-y.z,d=Math.hypot(dx,dz);if(d<2.1&&Math.abs(x.y-y.y)<2){if(d<.01){dx=.1;dz=0;d=.1;}let push=(2.1-d)*.5;x.x+=dx/d*push;x.z+=dz/d*push;y.x-=dx/d*push;y.z-=dz/d*push;}}
 for(const b of room.boxes){b.cooldown=Math.max(0,b.cooldown-dt);if(b.cooldown)continue;for(const p of active){const k=p.kart;if(!k.power&&k.pickup<=0&&Math.hypot(k.x-b.x,k.z-b.z)<2.8){const rank=ranking(room).findIndex(q=>q.id===p.id),pool=rank>1?['fibra','fibra','5g','club','bolsa','vpn','nube','telefono']:['telefono','vpn','bolsa','fibra','nube'];k.power=pool[Math.floor(Math.random()*pool.length)];k.pickup=1;b.cooldown=5;b.brokenAt=room.time;b.brokenBy=p.id;break;}}}
 for(const s of room.shots){s.x+=s.vx*dt;s.z+=s.vz*dt;s.life-=dt;for(const p of active)if(p.id!==s.owner&&Math.hypot(p.kart.x-s.x,p.kart.z-s.z)<2.2&&Math.abs(p.kart.y+1-s.y)<3){hit(p.kart);s.life=0;break;}}
 room.shots=room.shots.filter(s=>s.life>0);
 if(room.time>=room.finishDeadline||room.players.filter(p=>p.kart).every(p=>p.kart.finished))finishRace(room);
}
export function drivingBot(k,tr){const look=at(tr,k.s+10+k.speed*.35),desired=Math.atan2(look.x-k.x,look.z-k.z),error=angle(desired-k.yaw);return {steer:clamp(-error*2.4,-1,1),throttle:Math.abs(error)>.8?.6:1,brake:false};}
