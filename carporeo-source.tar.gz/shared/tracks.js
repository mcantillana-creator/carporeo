export const CHARACTERS=[{id:'entelin',name:'Entelin',color:'#177cff'},{id:'bluezon',name:'Bluezon',color:'#2348de'},{id:'bci',name:'Monos BCI',color:'#18bd89'},{id:'sencillin',name:'Sencillin',color:'#ec3755'},{id:'preunica',name:'Preunica',color:'#ff8b28'},{id:'fabler',name:'Fabler',color:'#f5cc45'}];
export const TRACKS=[
{id:'santiago',name:'Santiago',tag:'La ciudad es tu pista',feature:'Horquillas urbanas · compuertas alternas',color:'#23c6ee',sky:0x9edaff,ground:0x51897a,points:[[0, 0], [0, 170], [55, 235], [160, 235], [220, 180], [220, 90], [155, 55], [120, 5], [195, -55], [180, -150], [70, -180], [-40, -110]],height:2},
{id:'cordillera',name:'Cordillera',tag:'Corre entre las cumbres',feature:'Horquillas nevadas · bloques de hielo',color:'#b3e8ff',sky:0xc7e7ff,ground:0xadc2d2,points:[[0, 0], [0, 180], [60, 245], [135, 220], [140, 120], [205, 90], [255, 155], [315, 130], [320, 40], [255, -15], [180, -30], [160, -105], [255, -155], [200, -230], [70, -215], [-35, -130]],height:12},
{id:'tololo',name:'Cerro Tololo',tag:'Un circuito fuera de este mundo',feature:'Eses nocturnas · meteoritos y saltos',color:'#b18aff',sky:0x0c1231,ground:0x171c3b,points:[[0, 0], [0, 185], [70, 255], [160, 250], [185, 160], [270, 140], [320, 65], [260, 0], [165, 15], [130, -55], [195, -125], [150, -210], [60, -230], [-35, -150], [-80, -65]],height:9},
{id:'pacifico',name:'Océano Pacífico',tag:'La carrera sigue la costa',feature:'Chicanas del puerto · cargas suspendidas',color:'#29e6c5',sky:0x87daf1,ground:0x167b9b,points:[[0, 0], [0, 200], [65, 260], [135, 225], [145, 140], [215, 100], [275, 155], [330, 110], [310, 25], [240, -20], [210, -90], [260, -160], [190, -220], [80, -205], [25, -130], [-50, -85]],height:5},
{id:'atacama',name:'Desierto de Atacama',tag:'Acelera bajo el sol del desierto',feature:'Cañones cerrados · rocas y saltos',color:'#ffb86b',sky:0xffd8ad,ground:0xb67a4c,points:[[0, 0], [0, 200], [70, 260], [145, 240], [155, 145], [220, 110], [275, 180], [340, 155], [345, 70], [270, 20], [185, 10], [145, -55], [220, -95], [300, -80], [340, -155], [270, -230], [170, -240], [115, -155], [40, -145], [-35, -225], [-95, -160], [-65, -65]],height:7},
{id:'calibracion',name:'Laboratorio de conducción',tag:'Ajusta tu trazada',feature:'Recta · eses · rampa · barrera',color:'#ffb54b',sky:0xafd0e8,ground:0x627879,points:[[0,0],[0,220],[85,260],[145,180],[95,100],[160,35],[140,-70],[30,-100],[-50,-50]],height:2}
];
export const clamp=(n,a,b)=>Math.max(a,Math.min(b,n));
export const mod=(n,m)=>(n%m+m)%m;
export const angle=n=>Math.atan2(Math.sin(n),Math.cos(n));
const cat=(a,b,c,d,t)=>.5*((2*b)+(-a+c)*t+(2*a-5*b+4*c-d)*t*t+(-a+3*b-3*c+d)*t*t*t);
const cache=new Map();
export function buildTrack(id){
 if(cache.has(id))return cache.get(id);
 const def=TRACKS.find(t=>t.id===id)||TRACKS[0], points=[], count=600;
 for(let i=0;i<=count;i++){const u=(i%count)/count*def.points.length,k=Math.floor(u),t=u-k,p=j=>def.points[mod(j,def.points.length)];
 const x=cat(p(k-1)[0],p(k)[0],p(k+1)[0],p(k+2)[0],t),z=cat(p(k-1)[1],p(k)[1],p(k+1)[1],p(k+2)[1],t);
 const q=i/count, y=def.height*(.55+.45*Math.sin(q*Math.PI*4-.4))+(def.id==='calibracion'?0:18);
 points.push({x,z,y,s:i?points[i-1].s+Math.hypot(x-points[i-1].x,z-points[i-1].z):0});}
 const tr={...def,points,length:points[count].s,width:22,laps:3,difficulty:({santiago:1,pacifico:2,cordillera:3,tololo:4,atacama:5})[def.id]||1};
 cache.set(id,tr);return tr;
}
export function at(tr,s){s=mod(s,tr.length);let lo=0,hi=tr.points.length-1;while(hi-lo>1){let m=(lo+hi)>>1;if(tr.points[m].s>s)hi=m;else lo=m;}
 const a=tr.points[lo],b=tr.points[hi],d=b.s-a.s,f=(s-a.s)/d,tx=(b.x-a.x)/d,tz=(b.z-a.z)/d;
 return {x:a.x+(b.x-a.x)*f,z:a.z+(b.z-a.z)*f,y:a.y+(b.y-a.y)*f,tx,tz,nx:tz,nz:-tx,yaw:Math.atan2(tx,tz),s,index:lo};}
export function project(tr,x,z){let best=null,dist=Infinity;for(let i=0;i<tr.points.length-1;i++){const a=tr.points[i],b=tr.points[i+1],dx=b.x-a.x,dz=b.z-a.z,len2=dx*dx+dz*dz,t=clamp(((x-a.x)*dx+(z-a.z)*dz)/len2,0,1),px=a.x+t*dx,pz=a.z+t*dz,d=(x-px)**2+(z-pz)**2;if(d<dist){dist=d;const len=Math.sqrt(len2);best={x:px,z:pz,y:a.y+(b.y-a.y)*t,tx:dx/len,tz:dz/len,nx:dz/len,nz:-dx/len,s:a.s+t*len,index:i,offset:(x-px)*dz/len-(z-pz)*dx/len};}}return best;}
export function boxes(tr){return Array.from({length:8},(_,i)=>{const s=(i+.48)*tr.length/8;return [-6,0,6].map((lane,j)=>{const p=at(tr,s);return {id:`${i}-${j}`,s,x:p.x+p.nx*lane,z:p.z+p.nz*lane,y:p.y};});}).flat().filter(b=>!gapAt(tr,b.s,5));}
export function obstacles(tr){return [.23,.49,.74].map((q,i)=>{const p=at(tr,tr.length*q),lane=i%2?6:-6;return {x:p.x+p.nx*lane,z:p.z+p.nz*lane,y:p.y,r:1.6,s:p.s};}).filter(o=>!gapAt(tr,o.s,12));}

// Geometry and collision share these gap boundaries; no invisible road spans them.
const gapCache=new Map();
export function gaps(tr){
 if(gapCache.has(tr.id))return gapCache.get(tr.id);
 if(tr.id==='calibracion')return [];
 const result=[],length=16+tr.difficulty*2.5;
 for(const seed of (tr.difficulty===5?[.12,.44,.78]:[.13,.68])){
 let best=null,score=Infinity;
 for(const p of tr.points){if(p.s<90||p.s>tr.length-90)continue;
 if(result.some(g=>Math.abs(g.start-p.s)<150))continue;
 const yaw=at(tr,p.s-10).yaw,curve=Math.abs(angle(at(tr,p.s+length+15).yaw-yaw));
 const cost=curve*250+Math.abs(p.s-tr.length*seed)*.3;
 if(cost<score){score=cost;best=p;}}
 const end=tr.points.find(p=>p.s>=best.s+length).s;
 result.push({id:`gap-${result.length}`,start:best.s,end,length:end-best.s});
 }
 gapCache.set(tr.id,result);return result;
}
export function gapAt(tr,s,margin=0){s=mod(s,tr.length);return gaps(tr).find(g=>s>=g.start-margin&&s<=g.end+margin);}
const hazardCache=new Map();
export function hazards(tr){
 if(hazardCache.has(tr.id))return hazardCache.get(tr.id);
 const out=[];
 if(tr.id!=='calibracion'){
 const shift={santiago:0,cordillera:.015,tololo:-.015,pacifico:.025,atacama:-.025}[tr.id]||0;
 const cycle=4.3-tr.difficulty*.3;
 for(const [j,q] of (tr.difficulty>=4?[.25,.51,.85]:[.25,.51]).entries()){
 let s=tr.length*(q+shift);while(gapAt(tr,s,50))s+=8;
 for(let side=0;side<2;side++){
 const p=at(tr,s),lane=side?6:-6;
 out.push({...p,id:`drop-${j}-${side}`,kind:'drop',x:p.x+p.nx*lane,z:p.z+p.nz*lane,width:12,depth:6+tr.difficulty*.6,height:3,cycle,phase:side*cycle/2+j*.7});
 }}
 for(const q of [.39,.9]){let s=tr.length*q;while(gapAt(tr,s,50))s+=8;const p=at(tr,s);out.push({...p,id:`jump-${q}`,kind:'hurdle',width:24,depth:1.2,height:.7,phase:0});}
 }
 hazardCache.set(tr.id,out);return out;
}
export function hazardState(h,time){
 if(h.kind==='hurdle')return {lift:0,warning:false,blocked:true,falling:false};
 const cycle=h.cycle||4,phase=mod(time+h.phase,cycle)/cycle;
 const lift=phase<.19?7:phase<.24?7*(1-(phase-.19)/.05):phase<.43?0:phase<.55?7*(phase-.43)/.12:7;
 return {lift,warning:phase>=.07&&phase<.24,blocked:lift<2.4,falling:phase>=.19&&phase<.24};
}
export function rampZones(tr){return tr.id==='calibracion'?[.58]:[];}

// Signed curvature: positive turns towards the right-hand track normal.
// Each sampled segment carries an explicit negative-bank multiplier.
export function curveProfile(tr,s){
 const p=at(tr,s),curvature=angle(at(tr,s+10).yaw-at(tr,s-10).yaw)/20;
 const strength=tr.id==='calibracion'?0:clamp((Math.abs(curvature)-.012)/.022,0,1)*(.35+tr.difficulty*.1);
 return {curvature,contraperalte:strength,nx:p.nx,nz:p.nz};
}
export function outwardAcceleration(tr,s,speed){
 const c=curveProfile(tr,s);
 return {...c,force:-Math.sign(c.curvature)*Math.min(12,speed*speed*Math.abs(c.curvature)*c.contraperalte*.3)};
}
