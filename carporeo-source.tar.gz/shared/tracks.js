export const CHARACTERS=[{id:'entelin',name:'Entelin',color:'#177cff'},{id:'bluezon',name:'Bluezon',color:'#2348de'},{id:'bci',name:'Monos BCI',color:'#18bd89'},{id:'sencillin',name:'Sencillin',color:'#ec3755'},{id:'preunica',name:'Preunica',color:'#ff8b28'},{id:'fabler',name:'Fabler',color:'#f5cc45'}];
export const TRACKS=[
{id:'santiago',name:'Santiago',tag:'La ciudad es tu pista',feature:'Horquillas urbanas · compuertas alternas',color:'#23c6ee',sky:0x9edaff,ground:0x51897a,points:[[0, 0], [0, 160], [70, 215], [180, 210], [215, 170], [170, 135], [90, 145], [70, 105], [170, 70], [225, 0], [190, -100], [100, -150], [15, -125], [-45, -65]],height:2},
{id:'cordillera',name:'Cordillera',tag:'Corre entre las cumbres',feature:'Horquillas nevadas · bloques de hielo',color:'#b3e8ff',sky:0xc7e7ff,ground:0xadc2d2,points:[[0, 0], [0, 145], [75, 200], [180, 205], [225, 150], [170, 110], [80, 120], [65, 65], [155, 25], [210, -45], [170, -130], [70, -155], [-30, -80]],height:12},
{id:'tololo',name:'Cerro Tololo',tag:'Un circuito fuera de este mundo',feature:'Eses nocturnas · meteoritos y saltos',color:'#b18aff',sky:0x0c1231,ground:0x171c3b,points:[[0, 0], [0, 145], [80, 200], [160, 185], [205, 125], [160, 85], [90, 95], [65, 45], [130, 0], [210, -40], [190, -135], [100, -170], [15, -130], [-50, -60]],height:9},
{id:'pacifico',name:'Océano Pacífico',tag:'La carrera sigue la costa',feature:'Chicanas del puerto · cargas suspendidas',color:'#29e6c5',sky:0x87daf1,ground:0x167b9b,points:[[0, 0], [0, 155], [65, 210], [125, 190], [155, 130], [220, 140], [260, 70], [220, 10], [145, 10], [115, -35], [170, -100], [120, -170], [15, -150], [-45, -75]],height:5},
{id:'atacama',name:'Desierto de Atacama',tag:'Acelera bajo el sol del desierto',feature:'Cañones cerrados · rocas y saltos',color:'#ffb86b',sky:0xffd8ad,ground:0xb67a4c,points:[[0, 0], [0, 150], [75, 210], [175, 195], [210, 145], [160, 100], [85, 125], [60, 75], [125, 30], [210, -20], [230, -100], [140, -170], [70, -110], [5, -145], [-55, -70]],height:7},
{id:'calibracion',name:'Laboratorio de conducción',tag:'Ajusta tu trazada',feature:'Recta · eses · rampa · barrera',color:'#ffb54b',sky:0xafd0e8,ground:0x627879,points:[[0,0],[0,220],[85,260],[145,180],[95,100],[160,35],[140,-70],[30,-100],[-50,-50]],height:2}
];
export const clamp=(n,a,b)=>Math.max(a,Math.min(b,n));
export const mod=(n,m)=>(n%m+m)%m;
export const angle=n=>Math.atan2(Math.sin(n),Math.cos(n));
const cat=(a,b,c,d,t)=>.5*((2*b)+(-a+c)*t+(2*a-5*b+4*c-d)*t*t+(-a+3*b-3*c+d)*t*t*t);
const cache=new Map();
export function buildTrack(id){
 if(cache.has(id))return cache.get(id);
 const def=TRACKS.find(t=>t.id===id)||TRACKS[0], points=[], count=600;
 for(let i=0;i<=count;i++){const u=(i%count)/count*def.points.length,k=Math.floor(u),t=u-k,p=j=>def.points[mod(j,def.points.length)];
 const x=cat(p(k-1)[0],p(k)[0],p(k+1)[0],p(k+2)[0],t),z=cat(p(k-1)[1],p(k)[1],p(k+1)[1],p(k+2)[1],t);
 const q=i/count, y=def.height*(.55+.45*Math.sin(q*Math.PI*4-.4))+(def.id==='tololo'?13:0);
 points.push({x,z,y,s:i?points[i-1].s+Math.hypot(x-points[i-1].x,z-points[i-1].z):0});}
 const tr={...def,points,length:points[count].s,width:22,laps:3};
 cache.set(id,tr);return tr;
}
export function at(tr,s){s=mod(s,tr.length);let lo=0,hi=tr.points.length-1;while(hi-lo>1){let m=(lo+hi)>>1;if(tr.points[m].s>s)hi=m;else lo=m;}
 const a=tr.points[lo],b=tr.points[hi],d=b.s-a.s,f=(s-a.s)/d,tx=(b.x-a.x)/d,tz=(b.z-a.z)/d;
 return {x:a.x+(b.x-a.x)*f,z:a.z+(b.z-a.z)*f,y:a.y+(b.y-a.y)*f,tx,tz,nx:tz,nz:-tx,yaw:Math.atan2(tx,tz),s,index:lo};}
export function project(tr,x,z){let best=null,dist=Infinity;for(let i=0;i<tr.points.length-1;i++){const a=tr.points[i],b=tr.points[i+1],dx=b.x-a.x,dz=b.z-a.z,len2=dx*dx+dz*dz,t=clamp(((x-a.x)*dx+(z-a.z)*dz)/len2,0,1),px=a.x+t*dx,pz=a.z+t*dz,d=(x-px)**2+(z-pz)**2;if(d<dist){dist=d;const len=Math.sqrt(len2);best={x:px,z:pz,y:a.y+(b.y-a.y)*t,tx:dx/len,tz:dz/len,nx:dz/len,nz:-dx/len,s:a.s+t*len,index:i,offset:(x-px)*dz/len-(z-pz)*dx/len};}}return best;}
export function boxes(tr){return Array.from({length:8},(_,i)=>{const s=(i+.48)*tr.length/8;return [-6,0,6].map((lane,j)=>{const p=at(tr,s);return {id:`${i}-${j}`,s,x:p.x+p.nx*lane,z:p.z+p.nz*lane,y:p.y};});}).flat();}
export function obstacles(tr){return [.23,.49,.74].map((q,i)=>{const p=at(tr,tr.length*q),lane=i%2?6:-6;return {x:p.x+p.nx*lane,z:p.z+p.nz*lane,y:p.y,r:1.6};});}

// Shared deterministic course hazards: clients animate the same server clock.
const hazardCache=new Map();
export function hazards(tr){
 if(hazardCache.has(tr.id))return hazardCache.get(tr.id);
 const out=[];
 if(tr.id!=='calibracion'){
 const shift={santiago:0,cordillera:.015,tololo:-.015,pacifico:.025,atacama:-.025}[tr.id]||0;
 for(const [j,q] of [.24,.54].entries())for(let side=0;side<2;side++){
 const p=at(tr,tr.length*(q+shift)),lane=side?6:-6;
 out.push({...p,id:`drop-${j}-${side}`,kind:'drop',x:p.x+p.nx*lane,z:p.z+p.nz*lane,width:12,depth:4,height:3,phase:side*2.8+j*.7});
 }
 for(const q of [.41,.79]){const p=at(tr,tr.length*q);out.push({...p,id:`jump-${q}`,kind:'hurdle',width:24,depth:1.2,height:.55,phase:0});}
 }
 hazardCache.set(tr.id,out);return out;
}
export function hazardState(h,time){
 if(h.kind==='hurdle')return {lift:0,warning:false,blocked:true};
 const phase=mod(time+h.phase,5.6);
 const lift=phase<1.2?7:phase<1.5?7*(1-(phase-1.2)/.3):phase<2.8?0:phase<3.6?7*(phase-2.8)/.8:7;
 return {lift,warning:phase>=.45&&phase<1.5,blocked:lift<2.4};
}
export function rampZones(tr){return tr.id==='calibracion'?[.58]:[.765];}
